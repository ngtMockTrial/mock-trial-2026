# Obsidianの構造とCLI運用

2026-10-21。新規導入のObsidianスキルを使い、構造化と標準グラフを再構築しました。事件の証拠評価・人の判断を変更した作業ではありません。

## 保存場所と責任

| 層 | 場所 | 役割 |
|---|---|---|
| 原資料 | `00_元資料/` | 出典。上書き・移動・削除しない |
| 正本 | `検討/ノート/*.md` | 命題・出典・前提・反論・確認・人のレビュー |
| 一覧 | `検討/論証一覧.base` | 種類・立場・準備確認の5ビュー。属性編集は正本へ反映 |
| 標準グラフ用派生 | `検討/グラフ表示/` | 命題と関係を表示する自動生成ノート |
| 拡張設定 | `.obsidian/plugins/extended-graph/data.json` | 個別サイズ・形・自然配置・表示状態 |
| 補助図 | 全体Canvas一枚、接続閲覧画面 | 既存の人の配置・手描きと文章での検討を保持 |

正本のID・パスは維持し、別名にIDと日本語の命題名、タグに立場・種類を追加。属性とBasesで構造を整理し、複数の重複した正本へ分けていません。

## 独立した四つの軸

`side`＝立場、`kind`＝証拠・事実命題・推認等、`status`＝資料・命題の状態、`display_priority`＝表示重要度。人の判断は別の`review`・`reviewer`・`reviewed_on`です。採否とレビューを混同しません。

点のサイズは正本の重要度から派生先の`node_size`へ換算し、Extended Graphが描画します。対応は5→460、4→280、3→180、2→100、1→65。関係の点は35。これらはプラグインの描画値で、証拠力や有罪確率ではありません。正本では`display_priority`を編集し、派生先の`node_size`を直接変更しません。

方向は`inputs`：前提→対象、`challenges`：反論→対象、`checks`：確認課題→対象、`preparation`：準備資料→供述候補、`potential_supports`：候補→将来の支持対象。準備・候補は現在の証拠支持ではありません。E07・E09、W01・W02の扱いは維持しています。

## CLI

初回に有効化した公式CLIを利用します。Windowsの実行ファイルは `C:/Users/ryupc/AppData/Local/Programs/Obsidian/Obsidian.com`。PATH登録済みなら以下の`obsidian`を使用できます。アプリ内の操作・プラグイン管理・画面取得もCLIで行います。

```powershell
obsidian help
obsidian read path="検討/ノート/T00.md"
obsidian property:read path="検討/ノート/R01.md" name=display_priority
python 作成用/reasoning_graph.py
python 作成用/reasoning_graph.py --check
obsidian reload
obsidian command id=graph:open
obsidian plugin:reload id=extended-graph
obsidian base:query path="検討/論証一覧.base" view="弁護側" format=json
obsidian dev:errors
obsidian dev:screenshot path="作成用/構造化確認/標準グラフ_自然配置.png"
```

`検討を更新.cmd`は生成処理と、起動中のObsidianの再読込をまとめた入口です。初期設定をやり直す処理は通常更新へ含めません。グラフは固定配置せず、標準の引力・反発力で自然に集めます。人が後から配置設定やピンを変更した場合、通常更新で上書きしません。

## 変更記録

検証結果：正本43件の既存属性・本文・出典・支持反論関係・採否・人のレビューを再構築前の履歴ZIPと照合し保持を確認。Canvasの全配置も保持。整合性検査と21テストを通過。CLIで標準グラフ101点・固定ピン0・T00の実サイズが全点中最大であること、Bases43件、アプリのエラーなしを確認。原稿化ゲートは未レビュー・留保・反論未応答を理由に保留（終了コード2）のままで、表示変更によって解除していない。実画面は`作成用/構造化確認/標準グラフ_自然配置.png`。

- 2026-10-21：表示属性・Bases・標準グラフ拡張を追加。専用ビューを作る解釈と固定配置を撤回し、ユーザーの参考画像に合わせて自然な標準グラフへ修正。試作は履歴ZIPに退避し、有効プラグインから除外。原資料・証拠状態・レビュー・支持反論関係は維持。

外部参考：[公式CLI](https://obsidian.md/help/cli)、[Extended Graph](https://github.com/ElsaTam/obsidian-extended-graph)。確認日2026-10-21。事件教材とは別の表示ツール資料です。
